import json
import sqlite3
import time
from contextlib import closing
from pathlib import Path
from typing import List, Optional
from urllib.parse import quote

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from drawing import RateLimiter, parse_line

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "drawings.db"
STATIC_DIR = BASE_DIR / "static"
IMAGES_DIR = STATIC_DIR / "images"

LINE_LIFETIME = 1800     # секунд: мазки старше 30 минут стираются
MAX_LINES_IN_DB = 20000  # страховка от разрастания базы

# Папка static нужна приложению при старте: если её нет, создаём пустую,
# иначе сервер падает с ошибкой, ещё не показав страницу.
IMAGES_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI()
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")


# =====================================================================
# ДАННЫЕ САЙТА (редактируйте здесь)
# =====================================================================
MAGAZINE_PORTFOLIO = [
    {"image": "portfolio1.JPG", "title": "Журналы «Матуліна сонейка» и «Заикина библиотека»"},
    {"image": "portfolio2.JPG", "title": "Иллюстрации к книге «Пачастунак для Цмока»"},
    {"image": "portfolio3.JPG", "title": "Иллюстрации к книге «Падарожжа ў Новы Год»"},
    {"image": "portfolio4.JPG", "title": "Проявление заботы"}
]

BOOKS = [
    {
        "title": "Пачастунак для Цмока",
        "subtitle": "Рассмотреть развороты книги",
        "pages": ["tsmok_1.jpg", "tsmok_2.jpg", "tsmok_3.jpg", "tsmok_4.jpg", "tsmok_5.jpg", "tsmok_6.jpg"]
    },
    {
        "title": "Приключения Lисёнка",
        "subtitle": "Серия детских иллюстраций",
        "pages": ["lisenok_1.jpg", "lisenok_2.jpg", "lisenok_3.jpg", "lisenok_4.jpg"]
    },
    {
        "title": "Падарожжа ў Новы Год",
        "subtitle": "Зимняя сказка",
        "pages": ["novigod_1.jpg", "novigod_2.jpg", "novigod_3.jpg", "novigod_4.jpg"]
    }
]

# Герои для мини-игры «найди героев». Имена и книги ПРИМЕРНЫЕ: поменяйте на настоящих.
#   image   : файл PNG с прозрачным фоном в static/images/ (нет файла, покажется emoji)
#   section : где прячется (intro, portfolio, gallery, contacts)
#   left/top: положение в разделе в процентах, size: размер в px, rot: поворот в градусах
#   hint    : подсказка в коллекции, пока герой не найден
CHARACTERS = [
    {"id": "rabbit", "name": "Кролик-хранитель", "book": "Сказочные истории", "emoji": "🐰",
     "image": "char_rabbit.png", "section": "intro", "left": 3, "top": 84, "size": 70, "rot": -8,
     "hint": "Дремлет в самом начале сказки"},
    {"id": "tsmok", "name": "Цмок", "book": "Пачастунак для Цмока", "emoji": "🐲",
     "image": "char_tsmok.png", "section": "portfolio", "left": 91, "top": 4, "size": 80, "rot": 6,
     "hint": "Выглядывает среди избранных работ"},
    {"id": "lisenok", "name": "Лисёнок", "book": "Приключения Lисёнка", "emoji": "🦊",
     "image": "char_lisenok.png", "section": "gallery", "left": 2, "top": 20, "size": 70, "rot": -6,
     "hint": "Прячется рядом с книжными проектами"},
    {"id": "owl", "name": "Сова-ночница", "book": "Падарожжа ў Новы Год", "emoji": "🦉",
     "image": "char_owl.png", "section": "gallery", "left": 93, "top": 62, "size": 66, "rot": 8,
     "hint": "Смотрит на страницы зимней сказки"},
    {"id": "hedgehog", "name": "Ёжик", "book": "Приключения Lисёнка", "emoji": "🦔",
     "image": "char_hedgehog.png", "section": "portfolio", "left": 3, "top": 90, "size": 62, "rot": 0,
     "hint": "Скромно сидит у края портфолио"},
    {"id": "snowman", "name": "Снеговик", "book": "Падарожжа ў Новы Год", "emoji": "⛄",
     "image": "char_snowman.png", "section": "contacts", "left": 46, "top": 4, "size": 66, "rot": -4,
     "hint": "Ждёт в самом конце, где можно написать художнице"},
]


def make_img_resolver():
    """Возвращает функцию img(имя) -> адрес картинки.

    Хостинги на Linux различают регистр: portfolio1.JPG и portfolio1.jpg для них разные
    файлы. Из-за этого картинки «не грузятся», хотя на Windows всё работало. Здесь имя
    подбирается без учёта регистра по тому, что реально лежит в static/images.
    """
    try:
        files = {p.name.lower(): p.name for p in IMAGES_DIR.iterdir() if p.is_file()}
    except OSError:
        files = {}

    def img(name: str) -> str:
        return "/static/images/" + quote(files.get(name.lower(), name))

    return img


def report_missing_images():
    """При запуске пишет в консоль, каких картинок не хватает."""
    try:
        present = {p.name.lower() for p in IMAGES_DIR.iterdir()}
    except OSError:
        present = set()
    wanted = ["photo.jpg", "paper.jpg", "character1.png"]
    wanted += [i["image"] for i in MAGAZINE_PORTFOLIO]
    wanted += [p for b in BOOKS for p in b["pages"]]
    missing = [n for n in wanted if n.lower() not in present]
    if missing:
        print(f"[сайт] Нет картинок в {IMAGES_DIR}: " + ", ".join(missing))
    else:
        print("[сайт] Все основные картинки на месте")


def connect_db() -> sqlite3.Connection:
    return sqlite3.connect(DB_PATH)


# Инициализация базы данных SQLite
def init_db():
    with closing(connect_db()) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS lines (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                prevX REAL, prevY REAL, currX REAL, currY REAL,
                color TEXT, size REAL, timestamp REAL
            )
        """)
        conn.commit()


init_db()
report_missing_images()


# =====================================================================
# МЕНЕДЖЕР ВЕБ-СОКЕТОВ ДЛЯ МГНОВЕННОЙ РАССЫЛКИ ЛИНЕЙНЫХ МАЗКОВ
# =====================================================================
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, message: str, exclude: Optional[WebSocket] = None):
        # Рассылаем мазок всем, кроме автора (он уже нарисовал его у себя)
        for connection in list(self.active_connections):
            if connection is exclude:
                continue
            try:
                await connection.send_text(message)
            except Exception:
                self.disconnect(connection)


manager = ConnectionManager()


# =====================================================================
# МАРШРУТЫ И ЭНДПОИНТЫ СЕРВЕРА
# =====================================================================

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    # Очистка базы: старые линии и всё, что сверх лимита
    with closing(connect_db()) as conn:
        conn.execute("DELETE FROM lines WHERE ? - timestamp > ?", (time.time(), LINE_LIFETIME))
        conn.execute(
            "DELETE FROM lines WHERE id NOT IN (SELECT id FROM lines ORDER BY id DESC LIMIT ?)",
            (MAX_LINES_IN_DB,),
        )
        conn.commit()

    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "portfolio": MAGAZINE_PORTFOLIO,
            "books": BOOKS,
            "characters": CHARACTERS,
            "img": make_img_resolver(),
        }
    )


# Этот эндпоинт нужен только для первоначальной загрузки истории при входе на сайт
@app.get("/api/get_lines")
async def get_lines():
    with closing(connect_db()) as conn:
        rows = conn.execute(
            "SELECT prevX, prevY, currX, currY, color, size FROM lines"
        ).fetchall()

    lines = [
        {"prevX": r[0], "prevY": r[1], "currX": r[2], "currY": r[3], "color": r[4], "size": r[5]}
        for r in rows
    ]
    return JSONResponse(content={"lines": lines})


# ---------------------------------------------------------------------
# ЖИВОЙ ТУННЕЛЬ WEBSOCKET
# ---------------------------------------------------------------------
@app.websocket("/ws/draw")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    limiter = RateLimiter()
    try:
        while True:
            # Ждём мазок от JavaScript клиента
            raw = await websocket.receive_text()

            # Слишком частые сообщения и мусор молча отбрасываем
            if not limiter.allow():
                continue
            line = parse_line(raw)
            if line is None:
                continue

            # Сохраняем проверенную линию в SQLite, чтобы она не пропала
            with closing(connect_db()) as conn:
                conn.execute(
                    "INSERT INTO lines (prevX, prevY, currX, currY, color, size, timestamp) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (line["prevX"], line["prevY"], line["currX"], line["currY"],
                     line["color"], line["size"], time.time())
                )
                conn.commit()

            # Мгновенно пересылаем всем (уже очищенные данные, а не сырой текст клиента)
            await manager.broadcast(json.dumps(line), exclude=websocket)

    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        print(f"Ошибка сокета: {e}")
        manager.disconnect(websocket)
