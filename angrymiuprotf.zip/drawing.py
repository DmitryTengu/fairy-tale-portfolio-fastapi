"""Проверка мазков, которые приходят от браузеров по WebSocket.

Без этой проверки любой посетитель мог бы прислать на сервер что угодно:
гигантские числа, мусор вместо цвета, тысячи сообщений в секунду.
Модуль не зависит от FastAPI, поэтому его легко тестировать отдельно.
"""
import json
import math
import re
import time
from collections import deque
from typing import Optional

# Допустимый цвет: #rgb, #rrggbb или rgb()/rgba() с числами
COLOR_RE = re.compile(
    r"^(#[0-9a-fA-F]{3,8}"
    r"|rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(,\s*\d*\.?\d+\s*)?\))$"
)

MAX_MESSAGE_LEN = 400      # символов в одном сообщении
MAX_X = 10_000             # px, шире экрана не бывает
MAX_Y = 100_000            # px, высота всей страницы со скроллом
MIN_SIZE, MAX_SIZE = 1.0, 30.0
MAX_MESSAGES_PER_SECOND = 240


def _number(value, low: float, high: float) -> Optional[float]:
    """Число в пределах [low, high] или None (bool и NaN/inf не принимаем)."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if not math.isfinite(value) or value < low or value > high:
        return None
    return float(value)


def parse_line(raw: str) -> Optional[dict]:
    """Разбирает сообщение клиента. Возвращает чистый словарь мазка или None."""
    if not isinstance(raw, str) or len(raw) > MAX_MESSAGE_LEN:
        return None
    try:
        data = json.loads(raw)
    except ValueError:
        return None
    if not isinstance(data, dict):
        return None

    line = {
        "prevX": _number(data.get("prevX"), 0, MAX_X),
        "prevY": _number(data.get("prevY"), 0, MAX_Y),
        "currX": _number(data.get("currX"), 0, MAX_X),
        "currY": _number(data.get("currY"), 0, MAX_Y),
        "size": _number(data.get("size"), MIN_SIZE, MAX_SIZE),
    }
    color = data.get("color")
    if any(v is None for v in line.values()):
        return None
    if not isinstance(color, str) or not COLOR_RE.match(color):
        return None
    line["color"] = color
    return line


class RateLimiter:
    """Не больше N сообщений в секунду с одного подключения."""

    def __init__(self, limit: int = MAX_MESSAGES_PER_SECOND):
        self.limit = limit
        self._stamps: deque = deque()

    def allow(self, now: Optional[float] = None) -> bool:
        now = time.monotonic() if now is None else now
        while self._stamps and now - self._stamps[0] > 1.0:
            self._stamps.popleft()
        if len(self._stamps) >= self.limit:
            return False
        self._stamps.append(now)
        return True
